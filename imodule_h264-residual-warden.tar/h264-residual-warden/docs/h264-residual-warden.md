# h264-residual-warden - Tấn công và chống lỗi trong giấu tin H.264 bằng hệ số phần dư

## Nội dung và hướng dẫn bài thực hành

## Mục đích

Giúp sinh viên hiểu ảnh hưởng của active warden đối với kỹ thuật giấu tin trong chuẩn H.264 bằng hệ số phần dư. Sinh viên sẽ thực hành hai cách giấu tin: giấu naive trên vùng tần số cao và giấu có lặp bit trên vùng tần số trung bình. Sau đó sinh viên mô phỏng các tấn công phá tin ẩn và so sánh kết quả tách tin của hai phương pháp.

## Yêu cầu đối với sinh viên

Sinh viên cần có kiến thức cơ bản về hệ điều hành Linux, thao tác dòng lệnh, giấu tin, chuẩn H.264, hệ số QDCT phần dư, thứ tự quét zig-zag, parity bit và khái niệm active warden.

## Nội dung thực hành

### Tải bài lab

Tương tự các bài lab mẫu, sinh viên tải bài lab bằng lệnh `imodule`.

Nếu bài lab được dùng trực tiếp trên máy ảo đã tạo sẵn trong buổi thực hành, dùng link cục bộ:

```bash
imodule file:///home/student/imodules/imodule_h264-residual-warden.tar
```

Khi đưa bài lab lên kho phát hành, có thể thay link cục bộ bằng link tải công khai theo dạng:

```bash
imodule https://github.com/ptitdseclab/imodule/raw/refs/heads/main/imodule_h264-residual-warden.tar
```

### Khởi động bài lab

Vào terminal trên máy ảo Labtainer, gõ:

```bash
labtainer h264-residual-warden
```

Chú ý: sinh viên sử dụng mã sinh viên của mình để nhập thông tin email người thực hiện bài lab khi có yêu cầu, để sử dụng khi chấm điểm.

Sau khi khởi động xong, một terminal ảo sẽ xuất hiện, đại diện cho máy thực hành:

```text
h264-residual-warden
```

Trong terminal của bài lab, di chuyển về thư mục làm việc:

```bash
cd /home/ubuntu
```

Kiểm tra các file được cung cấp:

```bash
ls -l
```

Các file quan trọng gồm:

```text
sample_qdct_blocks.json
h264_residual_tool.py
secret.txt
lab2_answers.txt
```

Trong bài lab này, `sample_qdct_blocks.json` chứa các block hệ số QDCT phần dư 4x4 đã lượng tử hóa. Sinh viên sẽ sử dụng các hệ số này để giấu, tách và kiểm tra khả năng chống tấn công.

### Tìm hiểu mô hình active warden

Active warden là đối tượng cố tình xử lý lại dữ liệu mang tin ẩn nhằm phá thông điệp bí mật. Với video H.264, active warden có thể:

- Xóa hoặc làm suy giảm hệ số tần số cao.
- Lượng tử hóa lại hệ số phần dư.
- Làm nhiễu parity của các hệ số nghi ngờ chứa tin.

Lab này so sánh hai cách giấu tin:

```text
Naive high-band: mỗi bit được giấu một lần trong vùng tần số cao.
Repeated mid-band: mỗi bit được giấu 5 lần trong vùng tần số trung bình, khi tách dùng majority vote.
```

Quy tắc parity vẫn giống Lab 1:

- Hệ số chẵn biểu diễn bit `0`.
- Hệ số lẻ biểu diễn bit `1`.
- Không sử dụng hệ số DC `z(0,0)`.
- Chỉ chọn hệ số AC khác 0 theo thứ tự zig-zag.

### Phần 1: Khảo sát vùng high-band

Trên terminal bài lab, chạy:

```bash
inspect_residual --in sample_qdct_blocks.json --band high
```

Quan sát các thông tin:

```text
candidate_coefficients
capacity_bits
parity_even
parity_odd
zigzag_histogram
```

Mở file trả lời:

```bash
nano lab2_answers.txt
```

Ghi lại:

```text
Phan 1 - khao sat high-band
So he so co the dung de giau tin:
Dung luong bit:
Nhan xet ve vung high-band:
```

### Phần 2: Giấu tin naive trên vùng high-band

Thông điệp cần giấu là:

```text
ROBUST
```

Chạy lệnh:

```bash
embed_residual --in sample_qdct_blocks.json --message "ROBUST" --out naive_stego.json --band high --repeat 1
```

Trong phương pháp này, mỗi bit chỉ được giấu một lần. File đầu ra là:

```text
naive_stego.json
```

Tách thông điệp:

```bash
extract_residual --in naive_stego.json --band high --repeat 1
```

Kết quả đúng:

```text
recovered_message=ROBUST
```

Ghi vào `lab2_answers.txt`:

```text
Phan 2 - naive high-band
Thong diep goc:
Thong diep tach duoc truoc tan cong:
Repeat:
So he so da thay doi:
```

### Phần 3: Tấn công naive bằng zero-high

Tấn công `zero-high` mô phỏng việc loại bỏ các hệ số tần số cao. Đây là dạng xử lý thường gặp khi video bị nén mạnh, vì vùng tần số cao thường chứa chi tiết nhỏ và dễ bị loại bỏ.

Chạy lệnh:

```bash
attack_residual --in naive_stego.json --mode zero-high --threshold 11 --out naive_attacked.json --band high
```

So sánh thông điệp sau tấn công với thông điệp gốc:

```bash
compare_residual --in naive_attacked.json --expected "ROBUST" --band high --repeat 1
```

Kết quả dự kiến:

```text
bit_error_rate=1.000
```

Ghi vào `lab2_answers.txt`:

```text
Phan 3 - tan cong zero-high
Dang tan cong:
Thong diep tach duoc sau tan cong:
Bit error rate:
Nhan xet vi sao naive high-band bi pha:
```

### Phần 4: Giấu tin có lặp bit trên vùng mid-band

Trong phần này, mỗi bit được giấu 5 lần. Khi tách, chương trình gom từng nhóm 5 bit và lấy kết quả theo majority vote. Nếu một số bản sao của bit bị sai nhưng đa số vẫn đúng, bit gốc vẫn được khôi phục.

Chạy lệnh:

```bash
embed_residual --in sample_qdct_blocks.json --message "ROBUST" --out robust_stego.json --band mid --repeat 5
```

Tách thông điệp:

```bash
extract_residual --in robust_stego.json --band mid --repeat 5
```

Kết quả đúng:

```text
recovered_message=ROBUST
```

Ghi vào `lab2_answers.txt`:

```text
Phan 4 - repeated mid-band
Thong diep goc:
Thong diep tach duoc truoc tan cong:
Repeat:
Vai tro cua majority vote:
Ly do dung mid-band:
```

### Phần 5: Tấn công parity-scrub

Tấn công `parity-scrub` mô phỏng active warden làm nhiễu parity của một phần các hệ số nghi ngờ chứa tin. Trong bài lab này, tỷ lệ scrub là 20%.

Chạy lệnh:

```bash
attack_residual --in robust_stego.json --mode parity-scrub --rate 0.20 --seed 264 --out robust_attacked.json --band mid
```

So sánh kết quả sau tấn công:

```bash
compare_residual --in robust_attacked.json --expected "ROBUST" --band mid --repeat 5
```

Kết quả dự kiến:

```text
recovered_message=ROBUST
bit_error_rate=0.000
```

Điều này cho thấy lặp bit và majority vote giúp thông điệp vẫn được tách đúng khi tỷ lệ lỗi chưa quá lớn.

Ghi vào `lab2_answers.txt`:

```text
Phan 5 - tan cong parity-scrub
Ty le scrub:
Thong diep tach duoc sau tan cong:
Bit error rate:
Nhan xet ve tac dung cua repeat=5:
```

### Phần 6: So sánh hai phương pháp

Hoàn thiện bảng sau trong `lab2_answers.txt`:

```text
Phuong phap              Vung he so     Repeat     Dang tan cong       Bit error rate     Nhan xet
Naive high-band          high           1          zero-high
Repeated mid-band        mid            5          parity-scrub
```

Gợi ý nhận xét:

- Naive high-band có cách giấu đơn giản nhưng dễ bị phá khi hệ số tần số cao bị xóa.
- Repeated mid-band tốn nhiều hệ số carrier hơn vì mỗi bit được giấu nhiều lần.
- Majority vote giúp sửa lỗi khi chỉ một phần bản sao của bit bị thay đổi.
- Nếu active warden biết chính xác quy tắc giấu và tấn công đủ mạnh, thông điệp vẫn có thể bị phá.

Kiểm tra lại file trả lời:

```bash
cat lab2_answers.txt
```

### Lệnh thực hành đầy đủ

Sinh viên có thể chạy tuần tự các lệnh sau:

```bash
inspect_residual --in sample_qdct_blocks.json --band high
embed_residual --in sample_qdct_blocks.json --message "ROBUST" --out naive_stego.json --band high --repeat 1
extract_residual --in naive_stego.json --band high --repeat 1
attack_residual --in naive_stego.json --mode zero-high --threshold 11 --out naive_attacked.json --band high
compare_residual --in naive_attacked.json --expected "ROBUST" --band high --repeat 1

embed_residual --in sample_qdct_blocks.json --message "ROBUST" --out robust_stego.json --band mid --repeat 5
extract_residual --in robust_stego.json --band mid --repeat 5
attack_residual --in robust_stego.json --mode parity-scrub --rate 0.20 --seed 264 --out robust_attacked.json --band mid
compare_residual --in robust_attacked.json --expected "ROBUST" --band mid --repeat 5
cat lab2_answers.txt
```

### Kiểm tra checkwork

Sau khi hoàn thành các bước thực hành và ghi so sánh vào `lab2_answers.txt`, sinh viên chạy:

```bash
checkwork
```

Nếu các bước naive high-band, repeated mid-band, tấn công, so sánh và phần nhận xét đã được ghi nhận, bảng kết quả sẽ hiển thị các mục tương ứng bằng ký hiệu `Y`.

### Kết thúc bài lab

Trên terminal đầu tiên của Labtainer, sử dụng câu lệnh sau để kết thúc bài lab:

```bash
stoplab h264-residual-warden
```

Khi bài lab kết thúc, một tệp zip lưu kết quả được tạo và lưu vào một vị trí được hiển thị bên dưới lệnh `stoplab`.

### Khởi động lại bài lab

Trong quá trình làm bài, nếu sinh viên cần thực hiện lại bài lab từ đầu, dùng câu lệnh:

```bash
labtainer -r h264-residual-warden
```
