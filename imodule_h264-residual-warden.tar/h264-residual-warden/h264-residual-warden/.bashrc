export PATH="$HOME/.local/bin:$PATH"
alias ll='ls -alF'
