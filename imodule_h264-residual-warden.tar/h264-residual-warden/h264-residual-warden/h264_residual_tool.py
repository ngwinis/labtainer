#!/usr/bin/env python3
import argparse
import json
import math
import random
import sys
from pathlib import Path

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(3,1),(2,2),(1,3),(2,3),(3,2),(3,3)
]
ZIGZAG_INDEX = {pos: i for i, pos in enumerate(ZIGZAG)}
BANDS = {
    'all-ac': (1, 15),
    'mid': (4, 11),
    'high': (6, 15),
    'tail': (10, 15),
}

def load_blocks(path):
    data = json.loads(Path(path).read_text())
    if isinstance(data, dict):
        blocks = data['blocks']
    else:
        blocks = data
    return data, blocks

def save_blocks(path, data, blocks):
    if isinstance(data, dict):
        data = dict(data)
        data['blocks'] = blocks
    else:
        data = blocks
    Path(path).write_text(json.dumps(data, indent=2) + '\n')

def sign_adjust(value):
    if value >= 0:
        return value + 1
    return value - 1

def text_to_bits(text):
    raw = text.encode('utf-8')
    if len(raw) > 65535:
        raise SystemExit('message is too long for 16-bit length header')
    bits = [(len(raw) >> i) & 1 for i in range(15, -1, -1)]
    for byte in raw:
        bits.extend((byte >> i) & 1 for i in range(7, -1, -1))
    return bits

def bits_to_text(bits):
    if len(bits) < 16:
        return '', 0, 'not enough bits for length header'
    n = 0
    for bit in bits[:16]:
        n = (n << 1) | (bit & 1)
    need = 16 + n * 8
    if len(bits) < need:
        return '', n, 'not enough bits for payload'
    out = bytearray()
    body = bits[16:need]
    for i in range(0, len(body), 8):
        byte = 0
        for bit in body[i:i+8]:
            byte = (byte << 1) | (bit & 1)
        out.append(byte)
    try:
        return out.decode('utf-8'), n, ''
    except UnicodeDecodeError:
        return out.decode('utf-8', errors='replace'), n, 'payload is not valid utf-8'

def band_range(name):
    if name not in BANDS:
        raise SystemExit('unknown band: %s' % name)
    return BANDS[name]

def candidates(blocks, band='high', include_zero=False):
    lo, hi = band_range(band)
    result = []
    for bi, block in enumerate(blocks):
        for zi, (r, c) in enumerate(ZIGZAG):
            if zi == 0 or zi < lo or zi > hi:
                continue
            val = block[r][c]
            if include_zero or val != 0:
                result.append((bi, r, c, zi))
    return result

def expand_bits(bits, repeat):
    out = []
    for bit in bits:
        out.extend([bit] * repeat)
    return out

def majority_bits(raw_bits, repeat):
    if repeat <= 1:
        return raw_bits
    out = []
    for i in range(0, len(raw_bits), repeat):
        group = raw_bits[i:i+repeat]
        if len(group) < repeat:
            break
        out.append(1 if sum(group) * 2 >= repeat else 0)
    return out

def embed(args):
    data, blocks = load_blocks(args.infile)
    bits = text_to_bits(args.message)
    work_bits = expand_bits(bits, args.repeat)
    places = candidates(blocks, args.band, include_zero=False)
    if len(places) < len(work_bits):
        raise SystemExit('capacity_bits=%d required_bits=%d' % (len(places), len(work_bits)))
    changed = 0
    for bit, (bi, r, c, zi) in zip(work_bits, places):
        val = blocks[bi][r][c]
        if abs(val) % 2 != bit:
            blocks[bi][r][c] = sign_adjust(val)
            changed += 1
    save_blocks(args.out, data, blocks)
    print('embedded_bits=%d message_bytes=%d repeat=%d band=%s changed_coefficients=%d output=%s' % (
        len(work_bits), len(args.message.encode('utf-8')), args.repeat, args.band, changed, args.out))

def extract(args):
    data, blocks = load_blocks(args.infile)
    places = candidates(blocks, args.band, include_zero=args.include_zero)
    raw_bits = [abs(blocks[bi][r][c]) % 2 for bi, r, c, zi in places]
    bits = majority_bits(raw_bits, args.repeat)
    text, n, warning = bits_to_text(bits)
    print('payload_bytes=%d repeat=%d band=%s usable_bits=%d' % (n, args.repeat, args.band, len(bits)))
    print('recovered_message=%s' % text)
    if warning:
        print('warning=%s' % warning)

def attack(args):
    data, blocks = load_blocks(args.infile)
    rnd = random.Random(args.seed)
    changed = 0
    if args.mode == 'requant':
        factor = max(2, args.strength)
        for block in blocks:
            for zi, (r, c) in enumerate(ZIGZAG):
                if zi == 0:
                    continue
                old = block[r][c]
                if old == 0:
                    continue
                new = int(math.copysign(int(round(abs(old) / factor)), old))
                block[r][c] = new
                if new != old:
                    changed += 1
    elif args.mode == 'zero-high':
        threshold = args.threshold
        for block in blocks:
            for zi, (r, c) in enumerate(ZIGZAG):
                if zi >= threshold and block[r][c] != 0:
                    block[r][c] = 0
                    changed += 1
    elif args.mode == 'flip-parity':
        places = candidates(blocks, args.band, include_zero=False)
        for bi, r, c, zi in places:
            if rnd.random() <= args.rate:
                blocks[bi][r][c] = sign_adjust(blocks[bi][r][c])
                changed += 1
    elif args.mode == 'parity-scrub':
        places = candidates(blocks, args.band, include_zero=False)
        for bi, r, c, zi in places:
            if rnd.random() > args.rate:
                continue
            target = rnd.randrange(2)
            if abs(blocks[bi][r][c]) % 2 != target:
                blocks[bi][r][c] = sign_adjust(blocks[bi][r][c])
                changed += 1
    else:
        raise SystemExit('unknown attack mode')
    save_blocks(args.out, data, blocks)
    print('attack_mode=%s changed_coefficients=%d output=%s' % (args.mode, changed, args.out))

def compare(args):
    data, blocks = load_blocks(args.infile)
    places = candidates(blocks, args.band, include_zero=args.include_zero)
    raw_bits = [abs(blocks[bi][r][c]) % 2 for bi, r, c, zi in places]
    bits = majority_bits(raw_bits, args.repeat)
    recovered, n, warning = bits_to_text(bits)
    expected_bits = text_to_bits(args.expected)
    recovered_bits = text_to_bits(recovered) if recovered else []
    limit = max(len(expected_bits), len(recovered_bits))
    errors = 0
    for i in range(limit):
        a = expected_bits[i] if i < len(expected_bits) else None
        b = recovered_bits[i] if i < len(recovered_bits) else None
        if a != b:
            errors += 1
    rate = errors / limit if limit else 0.0
    print('expected_message=%s' % args.expected)
    print('recovered_message=%s' % recovered)
    print('bit_errors=%d compared_bits=%d bit_error_rate=%.3f repeat=%d band=%s' % (errors, limit, rate, args.repeat, args.band))
    if warning:
        print('warning=%s' % warning)

def inspect(args):
    data, blocks = load_blocks(args.infile)
    places = candidates(blocks, args.band, include_zero=args.include_zero)
    even = 0
    odd = 0
    by_index = {}
    for bi, r, c, zi in places:
        val = blocks[bi][r][c]
        if abs(val) % 2:
            odd += 1
        else:
            even += 1
        by_index[zi] = by_index.get(zi, 0) + 1
    total = even + odd
    bias = abs(even - odd) / total if total else 0.0
    print('blocks=%d band=%s candidate_coefficients=%d capacity_bits=%d' % (len(blocks), args.band, len(places), len(places)//args.repeat))
    print('parity_even=%d parity_odd=%d parity_bias=%.3f repeat=%d' % (even, odd, bias, args.repeat))
    print('zigzag_histogram=%s' % ','.join('%d:%d' % (k, by_index[k]) for k in sorted(by_index)))

def main():
    parser = argparse.ArgumentParser(description='H.264 residual QDCT parity steganography lab tool')
    sub = parser.add_subparsers(dest='cmd')

    p = sub.add_parser('embed')
    p.add_argument('--in', dest='infile', required=True)
    p.add_argument('--message', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--band', choices=sorted(BANDS), default='high')
    p.add_argument('--repeat', type=int, default=1)
    p.set_defaults(func=embed)

    p = sub.add_parser('extract')
    p.add_argument('--in', dest='infile', required=True)
    p.add_argument('--band', choices=sorted(BANDS), default='high')
    p.add_argument('--repeat', type=int, default=1)
    p.add_argument('--include-zero', action='store_true')
    p.set_defaults(func=extract)

    p = sub.add_parser('attack')
    p.add_argument('--in', dest='infile', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--mode', choices=['requant','zero-high','flip-parity','parity-scrub'], required=True)
    p.add_argument('--strength', type=int, default=2)
    p.add_argument('--threshold', type=int, default=11)
    p.add_argument('--rate', type=float, default=0.35)
    p.add_argument('--seed', type=int, default=264)
    p.add_argument('--band', choices=sorted(BANDS), default='high')
    p.set_defaults(func=attack)

    p = sub.add_parser('compare')
    p.add_argument('--in', dest='infile', required=True)
    p.add_argument('--expected', required=True)
    p.add_argument('--band', choices=sorted(BANDS), default='high')
    p.add_argument('--repeat', type=int, default=1)
    p.add_argument('--include-zero', action='store_true')
    p.set_defaults(func=compare)

    p = sub.add_parser('inspect')
    p.add_argument('--in', dest='infile', required=True)
    p.add_argument('--band', choices=sorted(BANDS), default='high')
    p.add_argument('--repeat', type=int, default=1)
    p.add_argument('--include-zero', action='store_true')
    p.set_defaults(func=inspect)

    args = parser.parse_args()
    if args.cmd is None:
        parser.print_help()
        raise SystemExit(2)
    if getattr(args, 'repeat', 1) < 1:
        raise SystemExit('repeat must be >= 1')
    args.func(args)

if __name__ == '__main__':
    main()
