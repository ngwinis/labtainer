# h264-residual-coef - Giấu tin trong chuẩn H.264 bằng hệ số phần dư

## Nội dung và hướng dẫn bài thực hành

## Mục đích

Giúp sinh viên hiểu kỹ thuật giấu tin trong video chuẩn H.264 bằng cách thay đổi parity của hệ số lượng tử hóa phần dư. Sinh viên sẽ thực hành giấu một thông điệp bí mật vào các hệ số AC khác 0, tách lại thông điệp đã giấu, sau đó mô phỏng tấn công nén lại để quan sát khả năng bị phá hủy của thông tin ẩn.

## Yêu cầu đối với sinh viên

Sinh viên cần có kiến thức cơ bản về hệ điều hành Linux, thao tác dòng lệnh, khái niệm giấu tin, quy trình mã hóa video H.264, phần dư, biến đổi 4x4, lượng tử hóa và thứ tự quét zig-zag.

## Nội dung thực hành

### Tải bài lab

Tương tự các bài lab mẫu, sinh viên tải bài lab bằng lệnh `imodule`.

Nếu bài lab được dùng trực tiếp trên máy ảo đã tạo sẵn trong buổi thực hành, dùng link cục bộ:

```bash
imodule file:///home/student/imodules/imodule_h264-residual-coef.tar
```

Khi đưa bài lab lên kho phát hành, có thể thay link cục bộ bằng link tải công khai theo dạng:

```bash
imodule https://github.com/ptitdseclab/imodule/raw/refs/heads/main/imodule_h264-residual-coef.tar
```

### Khởi động bài lab

Vào terminal trên máy ảo Labtainer, gõ:

```bash
labtainer h264-residual-coef
```

Chú ý: sinh viên sử dụng mã sinh viên của mình để nhập thông tin email người thực hiện bài lab khi có yêu cầu, để sử dụng khi chấm điểm.

Sau khi khởi động xong, một terminal ảo sẽ xuất hiện, đại diện cho máy thực hành:

```text
h264-residual-coef
```

Trong terminal của bài lab, di chuyển về thư mục làm việc:

```bash
cd /home/ubuntu
```

Kiểm tra các file được cung cấp:

```bash
ls -l
```

Các file quan trọng gồm:

```text
sample_qdct_blocks.json
h264_residual_tool.py
secret.txt
lab1_answers.txt
```

Trong đó, `sample_qdct_blocks.json` là dữ liệu mô phỏng các block hệ số QDCT phần dư 4x4 sau bước lượng tử hóa trong H.264. Bài lab không giấu tin trực tiếp vào pixel mà giấu vào hệ số phần dư đã lượng tử hóa.

### Tìm hiểu nguyên tắc giấu tin

Trong chuẩn H.264, khối ảnh hiện tại được dự đoán từ thông tin không gian hoặc thời gian. Phần sai khác giữa khối gốc và khối dự đoán được gọi là phần dư. Phần dư được biến đổi và lượng tử hóa thành các hệ số QDCT.

Quy tắc giấu tin trong bài lab:

- Không sử dụng hệ số DC `z(0,0)`.
- Quét các hệ số trong block 4x4 theo thứ tự zig-zag.
- Chọn các hệ số AC khác 0 ở vùng tần số cao.
- Hệ số chẵn biểu diễn bit `0`.
- Hệ số lẻ biểu diễn bit `1`.
- Nếu hệ số đang chọn chưa đúng parity với bit cần giấu, sửa hệ số ít nhất có thể.

### Khảo sát dung lượng giấu tin

Trên terminal bài lab, chạy lệnh:

```bash
inspect_residual --in sample_qdct_blocks.json --band high
```

Quan sát các thông tin chương trình in ra:

```text
candidate_coefficients
capacity_bits
parity_even
parity_odd
zigzag_histogram
```

Ý nghĩa:

- `candidate_coefficients`: số hệ số có thể dùng để giấu tin.
- `capacity_bits`: số bit tối đa có thể giấu với cấu hình đang chọn.
- `parity_even`: số hệ số chẵn.
- `parity_odd`: số hệ số lẻ.
- `zigzag_histogram`: thống kê vị trí zig-zag của các hệ số được chọn.

Sinh viên mở file trả lời:

```bash
nano lab1_answers.txt
```

Ghi lại các thông tin:

```text
So he so co the dung de giau tin:
Dung luong bit:
Nhan xet ve phan bo parity:
```

### Giấu thông điệp bí mật

Thông điệp cần giấu trong bài lab là:

```text
PTIT-H264
```

Chạy lệnh:

```bash
embed_residual --in sample_qdct_blocks.json --message "PTIT-H264" --out stego.json --band high
```

Chương trình sẽ tạo file mới:

```text
stego.json
```

File này chứa các hệ số QDCT phần dư đã được sửa parity để mang thông điệp bí mật.

Kiểm tra file vừa tạo:

```bash
ls -l stego.json
```

Quan sát kết quả của lệnh giấu tin. Kết quả đúng sẽ có dạng:

```text
embedded_bits=88
message_bytes=9
repeat=1
band=high
changed_coefficients=...
output=stego.json
```

Trong đó, `embedded_bits=88` gồm 16 bit header độ dài và 72 bit nội dung của chuỗi `PTIT-H264`.

### Tách thông điệp từ dữ liệu đã giấu

Chạy lệnh:

```bash
extract_residual --in stego.json --band high
```

Nếu thực hiện đúng, chương trình sẽ in ra:

```text
recovered_message=PTIT-H264
```

Ghi kết quả vào `lab1_answers.txt`:

```text
Thong diep goc:
Thong diep tach duoc truoc tan cong:
```

### Tấn công dữ liệu đã giấu

Bài lab mô phỏng tấn công nén lại bằng chế độ `requant`. Tấn công này làm lượng tử hóa lại các hệ số, khiến nhiều hệ số AC bị thay đổi hoặc bị đưa về 0. Vì bit bí mật phụ thuộc vào parity của hệ số, việc lượng tử hóa lại có thể phá thông điệp đã giấu.

Chạy lệnh:

```bash
attack_residual --in stego.json --mode requant --strength 2 --out attacked.json --band high
```

Kết quả đúng có dạng:

```text
attack_mode=requant
changed_coefficients=...
output=attacked.json
```

Tách lại thông điệp sau tấn công:

```bash
extract_residual --in attacked.json --band high
```

So sánh với thông điệp gốc:

```bash
compare_residual --in attacked.json --expected "PTIT-H264" --band high
```

Kết quả dự kiến:

```text
bit_errors=88
compared_bits=88
bit_error_rate=1.000
```

Điều này cho thấy thông điệp đã giấu bị phá hủy sau quá trình requantization.

### Hoàn thành bài thực hành

Mở file trả lời:

```bash
nano lab1_answers.txt
```

Hoàn thiện các nội dung sau:

```text
Thong diep goc:
Thong diep tach duoc truoc tan cong:
Dang tan cong da dung:
Thong diep tach duoc sau tan cong:
Bit error rate:
Nhan xet vi sao requantization pha duoc tin da giau:
```

Gợi ý nhận xét:

- Kỹ thuật parity đơn giản phụ thuộc trực tiếp vào giá trị hệ số lượng tử hóa.
- Hệ số AC vùng tần số cao thường dễ bị thay đổi khi video bị nén lại.
- Khi hệ số bị đổi parity hoặc bị đưa về 0, bit bí mật không còn khôi phục chính xác được.

Kiểm tra lại file trả lời:

```bash
cat lab1_answers.txt
```

### Lệnh thực hành đầy đủ

Sinh viên có thể chạy tuần tự các lệnh sau:

```bash
inspect_residual --in sample_qdct_blocks.json --band high
embed_residual --in sample_qdct_blocks.json --message "PTIT-H264" --out stego.json --band high
extract_residual --in stego.json --band high
attack_residual --in stego.json --mode requant --strength 2 --out attacked.json --band high
extract_residual --in attacked.json --band high
compare_residual --in attacked.json --expected "PTIT-H264" --band high
cat lab1_answers.txt
```

### Kiểm tra checkwork

Sau khi hoàn thành các bước thực hành và ghi nhận xét vào `lab1_answers.txt`, sinh viên chạy:

```bash
checkwork
```

Nếu các lệnh giấu tin, tách tin, tấn công, so sánh và phần nhận xét đã được ghi nhận, bảng kết quả sẽ hiển thị các mục tương ứng bằng ký hiệu `Y`.

### Kết thúc bài lab

Trên terminal đầu tiên của Labtainer, sử dụng câu lệnh sau để kết thúc bài lab:

```bash
stoplab h264-residual-coef
```

Khi bài lab kết thúc, một tệp zip lưu kết quả được tạo và lưu vào một vị trí được hiển thị bên dưới lệnh `stoplab`.

### Khởi động lại bài lab

Trong quá trình làm bài, nếu sinh viên cần thực hiện lại bài lab từ đầu, dùng câu lệnh:

```bash
labtainer -r h264-residual-coef
```
